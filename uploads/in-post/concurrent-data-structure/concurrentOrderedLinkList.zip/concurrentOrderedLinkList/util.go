package concurrentOrderedLinkList

import (
	"sync/atomic"
	"unsafe"
)

// loadNext atomic load the next node
func (n *Node) loadNext() *Node {
	return (*Node)(atomic.LoadPointer((*unsafe.Pointer)(unsafe.Pointer(&n.next))))
}

// storeNext atomic store the next node
func (n *Node) storeNext(node *Node) {
	atomic.StorePointer((*unsafe.Pointer)(unsafe.Pointer(&n.next)), unsafe.Pointer(node))
}

// loadMarked atomic load the marked field of a filed
func (n *Node) loadMarked() bool {
	return atomic.LoadUint32(&n.marked) == 1
}

// storeMarked atomic store the marked filed of a node
func (n *Node) storeMarked(status uint32) {
	atomic.StoreUint32(&n.marked, status)
}

// findNode check if a node is already existed in the link list
func (l *LinkList) findNode(value int) (prev, next *Node, exist bool) {
	prev = l.head
	next = prev.loadNext()
	for next != nil && next.value < value {
		prev = next
		next = prev.loadNext()
	}

	if next != nil && next.value == value {
		return prev, next, true
	}

	return prev, next, false
}