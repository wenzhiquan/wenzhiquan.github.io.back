# Golang 训练营--语言篇大作业

## 作业相关
### 作业目的

此次作业旨在让同学们实践并发数据结构，增进对于并发数据结构的理解。以及了解如何在 Go 语言并发场景下合理评判数据结构的性能，使得大家以后可以根据不同的场景来选择合适的数据结构。

### 作业说明
```
提交时间：4月24日24点前，结果公布：4月27日
提交方式：提交一个GitHub/公司Gitlab的代码仓库的链接，具体见最底部文档链接
判定规则：
1. 大作业重在鼓励大家积极实践学习内容，拒绝抄袭和作弊行为。
2. 基础分：满分为200分，只要能够通过测试就算完成(通过go test -race)，因公司没有相关系统，最终结果以老师人工review为准。如未提交或未通过测试，分数为0分。
3. 附加分：20分，代码风格/思路清晰，备注得当，有readme文件等，可附加20分。
说明：按照课程中实践一的方法完成此数据结构，其他形式的默认不符合条件，比如用另一个数据结构直接加马甲完成的。另外，必须注明每个步骤对应的代码，加入类似 // Step 1. Find A and B 这样的注释增加可读性。
```

### 作业要求

使用 Go 语言完成一个 并发安全的有序链表（数据严格有序并且没有重复元素），即 《Golang 并发数据结构和算法实践》 中的 实践一。
- 完成 插入、查询 功能
- 完成 删除、遍历 功能
- 通过 [测试](https://gist.github.com/zhangyunhao116/dd9f6f2f984997db18943e0e8738d257)，并且不发生 data race

### 作业提交

https://wj.bytedance.com/q/74586/62Wq6Os5/b907/#/

## 实现

### 项目结构

```
- concurrent_ordered_link_list.go 主逻辑实现
- data_structure.go               数据接口及接口定义
- util.go                         工具函数
```

### 主要接口

|接口作用|接口|
|-|-|
|新建一个并发有序链表|NewLinkList() ConcurrentOrderedLinkList|
|查询是否包含某个节点|Contains(value int) bool|
|插入节点|Insert(value int) bool|
|删除节点|Delete(value int) bool|
|遍历链表|Range(f func(value int) bool)|
|返回链表长度|Len() int|

### 测试结果

```
go test .
# === RUN   TestNewLinkList
# --- PASS: TestNewLinkList (0.19s)
go test -race .
# === RUN   TestNewLinkList
# --- PASS: TestNewLinkList (26.06s)
```