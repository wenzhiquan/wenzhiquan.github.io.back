package concurrentOrderedLinkList

import (
	"sync/atomic"
)

// NewLinkList create an empty new link list
func NewLinkList() ConcurrentOrderedLinkList {
	return &LinkList{
		head: &Node{},
	}
}

// NewNode create a new Node
func NewNode(value int) *Node {
	return &Node{
		value: value,
	}
}

// Contains check if the value is exist
func (l *LinkList) Contains(value int) bool {
	// head node is a virtual node without data, so skip it
	temp := l.head.loadNext()
	for temp != nil {
		if temp.value == value {
			return true
		}
		temp = temp.loadNext()
	}

	return false
}

// Insert a node to link list
func (l *LinkList) Insert(value int) bool {
	for {
		// step 1, find if the value is already existed
		prev, next, found := l.findNode(value)
		// if existed, directly return false
		if found {
			return false
		}
		// step 2, lock node prev
		// check if prev node was marked which represents the prev node was deleted by another process
		// and check if prev.next != next which represents the next node was changed by another process
		// if the check not passed, unlock prev node and return to step 1
		prev.mu.Lock()
		if prev.loadMarked() || prev.next != next {
			prev.mu.Unlock()
			continue
		}

		// step 3, create a new node
		x := NewNode(value)
		// step 4, link the prev node, new node and next node
		x.next = next
		prev.storeNext(x)
		// step 5, unlock the prev node, the length of the link list add 1
		prev.mu.Unlock()
		atomic.AddInt64(&l.length, 1)
		return true
	}
}

// Delete the node of the value in the link list
func (l *LinkList) Delete(value int) bool {
	for {
		// step 1, find if the value is already existed
		prev, next, found := l.findNode(value)
		// if not existed, directly return false
		if !found {
			return false
		}
		// step 2, lock the next node
		// check if next node was marked which represents the next node was deleted by another process
		// if the next node was deleted, unlock next node and return to step 1
		next.mu.Lock()
		if next.loadMarked() {
			next.mu.Unlock()
			continue
		}
		// step 3, lock the prev node
		// check if prev node was marked which represents the prev node was deleted by another process
		// and check if prev.next != next which represents the next node was changed by another process
		// if the check not passed, unlock prev node and next node, then return to step 1
		prev.mu.Lock()
		if prev.loadMarked() || prev.next != next {
			next.mu.Unlock()
			prev.mu.Unlock()
			continue
		}

		// step 4, set next node as marked and modify the next pointer of prev node
		next.storeMarked(1)
		prev.storeNext(next.next)
		// step 5, unlock prev node and next node, the length of the link list minus 1
		next.mu.Unlock()
		prev.mu.Unlock()
		atomic.AddInt64(&l.length, -1)
		return true
	}
}

// Range get all value from the link list
func (l *LinkList) Range(f func(value int) bool) {
	// head node is a virtual node without data, so skip it
	temp := l.head.loadNext()
	for temp != nil {
		if temp.loadMarked() {
			temp = temp.loadNext()
			continue
		}
		if !f(temp.value) {
			return
		}
		temp = temp.loadNext()
	}
}

// Len return the length of the link list
func (l *LinkList) Len() int {
	return int(atomic.LoadInt64(&l.length))
}
